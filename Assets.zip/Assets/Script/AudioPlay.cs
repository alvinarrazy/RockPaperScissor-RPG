﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class AudioPlay : MonoBehaviour
{
   
    public AudioSource sound;
    public AudioSource winTheme;

    public void playSound()
    {
        sound.Play();
    }

    public void Winning()
    {
        winTheme.Play();
    }


    // Update is called once per frame
    void Update()
    {
        
    }
}
