﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UnitStat : MonoBehaviour
{
    public float HealthPoints;
    public float Attack;
}
