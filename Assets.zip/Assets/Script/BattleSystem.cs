﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;



public class GameManager : MonoBehaviour
{
    public static bool IsInputEnabled = true;
}

public class BattleSystem : MonoBehaviour
{
    bool rock1 = false; bool paper1 = false; bool scissors1 = false;
    bool rock2 = false; bool paper2 = false; bool scissors2 = false;
    public GameObject player1;
    public GameObject player2;
    public Text Message;
    public Text healthTextP1;
    public Text healthTextP2;

    public AudioSource selectSound;
    public AudioSource battleTheme;
    public AudioSource winTheme;

    public Button backMain;


    void Start()
    {
        UnitStat Player1CurrentHP = this.player1.GetComponent<UnitStat>();
        UnitStat Player2CurrentHP = this.player2.GetComponent<UnitStat>();

        healthTextP1.text = Player1CurrentHP.HealthPoints.ToString();
        healthTextP2.text = Player2CurrentHP.HealthPoints.ToString();
        Message.text = "Press the Key!!!";
        Reset();
        GameManager.IsInputEnabled = true;
        backMain.gameObject.SetActive(false);
    }


    void Reset()
    {
        rock1 = false;
        rock2 = false;
        paper1 = false;
        paper2 = false;
        scissors1 = false;
        scissors2 = false;
        player1.transform.localScale = new Vector3(1, 1, 1);
        player2.transform.localScale = new Vector3(1, 1, 1);
    }



    void Update()
    {
        UnitStat Player1Stat = this.player1.GetComponent<UnitStat>();
        UnitStat Player2Stat = this.player2.GetComponent<UnitStat>();
        Animator Player1anim = this.player1.GetComponent<Animator>();
        Animator Player2anim = this.player2.GetComponent<Animator>();
        if (Player2Stat.HealthPoints <= 0)
        {
            player2.transform.localScale = new Vector3(0, 0, 0);
            Player1anim.Play("Win");
            Message.text = "Player 1 WIN!!!";
            battleTheme.Stop();
            backMain.gameObject.SetActive(true);
        }
        else if (Player1Stat.HealthPoints <= 0)
        {
            player1.transform.localScale = new Vector3(0, 0, 0);
            Player2anim.Play("Win");
            Message.text = "Player 2 WIN!!!";
            battleTheme.Stop();
            backMain.gameObject.SetActive(true);
        }

        /*if (!rock1 && !paper1 && !scissors1)
        {
            if (Input.GetKeyUp(KeyCode.A))
            {
                rock1 = true;
                paper1 = false;
                scissors1 = false;
                selectSound.Play();
            }

            if (Input.GetKeyUp(KeyCode.S))
            {
                rock1 = false;
                paper1 = true;
                scissors1 = false;
                selectSound.Play();
            }

            if (Input.GetKeyUp(KeyCode.D))
            {
                rock1 = false;
                paper1 = false;
                scissors1 = true;
                selectSound.Play();
            }
        }
        if (!rock2 && !paper2 && !scissors2)
        {
            if (Input.GetKeyUp(KeyCode.J))
            {
                rock2 = true;
                paper2 = false;
                scissors2 = false;
                selectSound.Play();
            }

            if (Input.GetKeyUp(KeyCode.K))
            {
                rock2 = false;
                paper2 = true;
                scissors2 = false;
                selectSound.Play();
            }

            if (Input.GetKeyUp(KeyCode.L))
            {
                rock2 = false;
                paper2 = false;
                scissors2 = true;
                selectSound.Play();
            }
        }*/


        if (Input.GetKeyUp(KeyCode.A))
        {
            rock1 = true;
            paper1 = false;
            scissors1 = false;
            selectSound.Play();
        }

        if (Input.GetKeyUp(KeyCode.S))
        {
            rock1 = false;
            paper1 = true;
            scissors1 = false;
            selectSound.Play();
        }

        if (Input.GetKeyUp(KeyCode.D))
        {
            rock1 = false;
            paper1 = false;
            scissors1 = true;
            selectSound.Play();
        }

        if (Input.GetKeyUp(KeyCode.J))
        {
            rock2 = true;
            paper2 = false;
            scissors2 = false;
            selectSound.Play();
        }

        if (Input.GetKeyUp(KeyCode.K))
        {
            rock2 = false;
            paper2 = true;
            scissors2 = false;
            selectSound.Play();
        }

        if (Input.GetKeyUp(KeyCode.L))
        {
            rock2 = false;
            paper2 = false;
            scissors2 = true;
            selectSound.Play();
        }
        //conditions//

        if (rock1 == true && rock2 == true)
        {
            Message.text = "Its Draw!!";
            Reset();
        }
        if (rock1 == true && paper2 == true)
        {
            StartCoroutine(P2Win());
        }
        if (rock1 == true && scissors2 == true)
        {
            StartCoroutine(P1Win());
        }
        if (paper1 == true && paper2 == true)
        {
            Message.text = "Its Draw!!";
            Reset();
        }
        if (paper1 == true && rock2 == true)
        {
            StartCoroutine(P1Win());
        }
        if (paper1 == true && scissors2 == true)
        {
            StartCoroutine(P2Win());
        }
        if (scissors1 == true && scissors2 == true)
        {
            Message.text = "Its Draw!!";
            Reset();
        }
        if (scissors1 == true && paper2 == true)
        {
            StartCoroutine(P1Win());
        }
        if (scissors1 == true && rock2 == true)
        {
            StartCoroutine(P2Win());
        }

    }
    public IEnumerator P1Win()
    {
        enabled = false;
        Message.text = "WAIT FOR THE ANIMATION DONE!!";
        Animator Player1anim = this.player1.GetComponent<Animator>();
        Message.text = "WAIT FOR THE ANIMATION DONE!!";

        Player1anim.Play("Attack");

        yield return new WaitForSeconds(1);
        yield return new WaitForSeconds(Player1anim.GetCurrentAnimatorStateInfo(0).length + Player1anim.GetCurrentAnimatorStateInfo(0).normalizedTime);
        
        P2Damaged();


        StopCoroutine(P1Win());

        yield break;
    }
    public IEnumerator P2Win()
    {
        enabled = false;
        Message.text = "WAIT FOR THE ANIMATION DONE!!";
        Animator Player2anim = this.player2.GetComponent<Animator>();
        Message.text = "WAIT FOR THE ANIMATION DONE!!";


        Player2anim.Play("Attack");
        yield return new WaitForSeconds(1);
        yield return new WaitForSeconds(Player2anim.GetCurrentAnimatorStateInfo(0).length + Player2anim.GetCurrentAnimatorStateInfo(0).normalizedTime);
        P1Damaged();


        enabled = true;
        StopCoroutine(P2Win());
    }

    public void P1Damaged()
    {
        StopAllCoroutines();
        UnitStat Player1Stat = this.player1.GetComponent<UnitStat>();
        UnitStat Player2Stat = this.player2.GetComponent<UnitStat>();
        Animator Player2anim = this.player2.GetComponent<Animator>();
        //Player1Stat.HealthPoints -= Player2Stat.Attack;
        //healthTextP1.text = Player1Stat.HealthPoints.ToString();

        //if (Player1Stat.HealthPoints <= 0)
        //{
        //    Player2anim.Play("Win");
        //    Message.text = "Player 2 WIN!!!";
        //    battleTheme.Stop();
        //    winTheme.Play();
        //}
        Message.text = "Press the Key!!!";
        Reset();
        enabled = true;
    }

    public void P2Damaged()
    {
        StopCoroutine(P1Win());

        UnitStat Player1Stat = this.player1.GetComponent<UnitStat>();
        UnitStat Player2Stat = this.player2.GetComponent<UnitStat>();
        Animator Player1anim = this.player1.GetComponent<Animator>();

        //Player2Stat.HealthPoints -= Player1Stat.Attack;
        //healthTextP2.text = Player2Stat.HealthPoints.ToString();

        //if (Player2Stat.HealthPoints <= 0)
        //{
        //    Player1anim.Play("Win");
        //    Message.text = "Player 1 WIN!!!";
        //    battleTheme.Stop();
        //    winTheme.Play();
        //}

        Reset();
        Message.text = "Press the Key!!!";
        enabled = true;
    }
    public void Draw()
    {
        Message.text = "Its Draw!!";
        Reset();
    }


    public IEnumerator WaitUntilReloaded()
    {
        yield return new WaitForSeconds(3);
        StopCoroutine(WaitUntilReloaded());
    }


}
