﻿using System.Collections;
using System.Runtime;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using UnityEngine.SceneManagement;

public class WinTheme : MonoBehaviour
{
    public string mainMenuScene;
    public void Winning()
    {
        SceneManager.LoadScene(mainMenuScene);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
