﻿using System.Collections;
using System.Runtime;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Damaging : MonoBehaviour
{
    public GameObject target;
    public GameObject player;
    public Text targetHealthText;
    public Text Message;
   

    public void StartDamaging()
    {
        UnitStat PlayerStat = this.player.GetComponent<UnitStat>();
        UnitStat TargetStat = this.target.GetComponent<UnitStat>();
        System.Random random = new System.Random();
        float damageInflicted = (PlayerStat.Attack * random.Next(1, 4));
        TargetStat.HealthPoints -= damageInflicted;
        Message.text = damageInflicted + " Damage Inflicted!";
        if(TargetStat.HealthPoints < 0)
        {
            targetHealthText.text = "0";
        }
        else
        {
            targetHealthText.text = TargetStat.HealthPoints.ToString();
        }

        StartCoroutine(Damaged());
    }

    public IEnumerator Damaged()
    {
        target.transform.localScale = new Vector3(0, 0, 0);
        yield return new WaitForSeconds(Convert.ToSingle(0.1));
        target.transform.localScale = new Vector3(1, 1, 1);
        yield return new WaitForSeconds(Convert.ToSingle(0.1));
        target.transform.localScale = new Vector3(0, 0, 0);
        yield return new WaitForSeconds(Convert.ToSingle(0.1));
        target.transform.localScale = new Vector3(1, 1, 1);
        yield return new WaitForSeconds(Convert.ToSingle(0.1));
        target.transform.localScale = new Vector3(0, 0, 0);
        yield return new WaitForSeconds(Convert.ToSingle(0.1));
        target.transform.localScale = new Vector3(1, 1, 1);
        yield return new WaitForSeconds(Convert.ToSingle(0.1));
        target.transform.localScale = new Vector3(0, 0, 0);
        yield return new WaitForSeconds(Convert.ToSingle(0.1));
        target.transform.localScale = new Vector3(1, 1, 1);
        yield return new WaitForSeconds(Convert.ToSingle(0.1));
    }


    // Update is called once per frame
    void Update()
    {
        
    }
}
