﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectSound : MonoBehaviour
{
    public AudioSource selectSound;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyUp(KeyCode.A))
        {
            selectSound.Play();
        }else if (Input.GetKeyUp(KeyCode.S))
        {
            selectSound.Play();
        }else if (Input.GetKeyUp(KeyCode.D))
        {
            selectSound.Play();
        }else if (Input.GetKeyUp(KeyCode.J))
        {
            selectSound.Play();
        }else if(Input.GetKeyUp(KeyCode.K))
        {
            selectSound.Play();
        }else if (Input.GetKeyUp(KeyCode.L))
        {
            selectSound.Play();
        }
        else
        {

        }
    }
}
