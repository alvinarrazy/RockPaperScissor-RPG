﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthPoint : MonoBehaviour
{
   
    public Text health1;
    public Text health2;
    public float healthint1;
    public float healthint2;

    void Start()
    {
 
        health1.text = healthint1.ToString();
        health2.text = healthint2.ToString();

    }

    void Update()
    {

    }
}
